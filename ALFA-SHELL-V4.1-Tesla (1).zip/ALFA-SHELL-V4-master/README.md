..:: ALFA TEaM Shell ~ v4.1-Tesla ::..

<p>Name filter in file manager for quick access</p>
<p>Pop-up terminal, ability to opening multiple terminals simultaneously and customizing</p>
<p>History of terminal commands</p>
<p>History of SQL connections for quicker access to database</p>
<p>Advanced editor that able to change font size and style and supporting multiple programming languages</p>
<p>Opening, managing and editing multiple files simultaneously</p>
<p>Configuring Grabber to find private scripts' configuration</p>
<p>Sorting by name, size and last modifying date of files and folders</p>
<p>Viewing all options as pop-up and multi-tab view for accessing options quickly</p>
<p>Right click enabled on files, folders and options</p>
<p>Archive Manager for managing compressed files</p>
<p>Capability to control and terminating each tab's proccess</p>
<p>Column Dumper for Database (for extracting specific data such as usernames and emails)</p>
<p>Fake page for CPanel and Direct Admin</p>
<p>Separating Database Manager and pop-up view of it, and capability to opening unlimited number of databases together without interference</p>
<p>Paging folders with a lot of files for faster loading</p>
<p>Bug fixes and other minor improvements.</p>

<p>[+] New features:</p>

<p>Redesigned Mysql Manager ~ Easy and powerfull !</p>
<p>Multiple File Manager ! ~ You can open multiple folders at the same time and manage them</p>
<p>In the editor [ control +s ] shortkey has been added for save files</p>
<p>Added [ ALFA_DATA ] as a Alfa Parent Folder. Thats mean all folders like: alfacgiapi, alfasymlinks, etc... they will be craeted in the ALFA_DATA folder.</p>

Alfa Shell V4.1-Tesla
Just try once...

http://dl.solevisible.com<br>
https://telegram.me/solevisible

~ Alfa_Team/solevisible
