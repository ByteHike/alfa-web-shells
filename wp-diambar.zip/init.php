<?php
/**
 * Plugin Name: Diambar
 * Version: 1.0
 * Author: Solevisible
 */

if(isset($_GET["loadme"])){
	include("includes/loadme.php");
}

?>
